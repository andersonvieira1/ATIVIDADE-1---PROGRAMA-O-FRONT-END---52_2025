const toggle = document.getElementById("menu-toggle");
const navList = document.querySelector(".nav-list");
const topBtn = document.getElementById("topBtn");

// Menu toggle para mobile
toggle.addEventListener("click", () => {
  navList.classList.toggle("active");
});

// Botão voltar ao topo
window.addEventListener("scroll", () => {
  topBtn.style.display = window.scrollY > 300 ? "block" : "none";
});

topBtn.addEventListener("click", () => {
  window.scrollTo({ top: 0, behavior: "smooth" });
});

// Animação de fade ao aparecer
const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
      }
    });
  },
  { threshold: 0.1 }
);

document.querySelectorAll(".card, .section h2").forEach((el) => {
  el.classList.add("fade-in");
  observer.observe(el);
});
